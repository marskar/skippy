# The `skippy` python package

Skip the boilerplate of scikit-learn machine learning examples.

Abstracting away most of the code to focus on one step per line.

Look in the `pipelines` folder of the
[skippy repo](https://github.com/marskar/skippy)
for example pipelines.